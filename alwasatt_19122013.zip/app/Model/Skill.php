<?php
class Skill extends AppModel {
	
	public $name = 'Skill';
	
}
