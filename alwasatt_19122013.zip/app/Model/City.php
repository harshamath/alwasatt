<?php
class City extends AppModel {
	
	var $name = 'City';
	
}
