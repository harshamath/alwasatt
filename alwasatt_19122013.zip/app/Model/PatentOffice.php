<?php
App::uses('AppModel', 'Model');
/**
 * PatentOffice Model
 *
 */
class PatentOffice extends AppModel {

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'name';

}
