<?php

class UserType extends AppModel {
	
	public $name = 'UserType';
}
