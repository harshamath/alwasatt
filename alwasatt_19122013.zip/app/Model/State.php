<?php
class State extends AppModel {
	
	public $name = 'State';
	
}
