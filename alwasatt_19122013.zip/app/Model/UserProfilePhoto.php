<?php
class UserProfilePhoto extends AppModel {
	
	public $name = 'UserProfilePhoto';
}
