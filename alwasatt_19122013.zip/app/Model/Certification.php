<?php
App::uses('AppModel', 'Model');
/**
 * Certification Model
 *
 */
class Certification extends AppModel {

}
