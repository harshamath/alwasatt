<?php
class UserConnection extends AppModel {
	
	public $name = 'UserConnection';
}
